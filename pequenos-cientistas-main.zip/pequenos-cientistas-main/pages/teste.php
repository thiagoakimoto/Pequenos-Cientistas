<?php

$subjects = $_POST['subject'];

echo $subjects;