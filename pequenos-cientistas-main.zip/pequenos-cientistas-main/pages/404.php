<?php
echo "
    <script>
        alert('Página não encontrada');
        window.location.href = '/';
    </script>
";
